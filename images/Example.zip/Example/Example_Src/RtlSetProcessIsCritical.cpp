// RtlSetProcessIsCritical.cpp : Defines the entry point for the application.
//

#include <windows.h>

//////////////////////////////////////////////////////////////////////////
// Code from http://www.netcore2k.net/projects/freeram
// Enables specified privilege for process
//////////////////////////////////////////////////////////////////////////
BOOL EnablePriv(LPCSTR lpszPriv)
{
    HANDLE hToken;
    LUID luid;
    TOKEN_PRIVILEGES tkprivs;
    ZeroMemory(&tkprivs, sizeof(tkprivs));
    
    if(!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
        return FALSE;
    
    if(!LookupPrivilegeValue(NULL, lpszPriv, &luid)){
        CloseHandle(hToken); return FALSE;
    }
    
    tkprivs.PrivilegeCount = 1;
    tkprivs.Privileges[0].Luid = luid;
    tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    
    BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
    CloseHandle(hToken);
    return bRet;
}

//////////////////////////////////////////////////////////////////////////
// Function declaration for RtlSetProcessIsCritical
// ------------------------------------------------
// NewValue is the new critical setting - set it to 1 for a critical
//		process, 0 for a normal process
//
// OldValue, if not null, will receive the old setting for the process
//
// bNeedScb specifics whether system critical breaks will be required
//		(and already enabled) for the process
//////////////////////////////////////////////////////////////////////////
typedef long ( WINAPI *RtlSetProcessIsCritical ) (
		IN BOOLEAN	bNew, 
		OUT BOOLEAN	*pbOld, 
		IN BOOLEAN	bNeedScb );


//////////////////////////////////////////////////////////////////////////
// Main function
//////////////////////////////////////////////////////////////////////////
int APIENTRY WinMain(	HINSTANCE hInstance,
						HINSTANCE hPrevInstance,
						LPSTR     lpCmdLine,
						int       nCmdShow)
{
	// Enable the SE_DEBUG_NAME privilege
	if (EnablePriv(SE_DEBUG_NAME) != TRUE)
	{
		MessageBox(	NULL, "Could not enable SE_DEBUG_NAME privilege!", 
					"Error", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	// Load ntdll.dll so we can access the function
	HANDLE ntdll = LoadLibrary("ntdll.dll");
	if (ntdll == NULL)
	{
		MessageBox(	NULL, "Could not load ntdll.dll!", 
			"Error", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	// Declare the function and obtain it using GetProcAddress
	RtlSetProcessIsCritical SetCriticalProcess;
	SetCriticalProcess = (RtlSetProcessIsCritical) 
							GetProcAddress((HINSTANCE)ntdll, "RtlSetProcessIsCritical");

	if (!SetCriticalProcess)
	{
		MessageBox(	NULL, "Could not obtain function from ntdll!", 
			"Error", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	// Call it - enable system critical status
	SetCriticalProcess(TRUE, NULL, FALSE);
	MessageBox(NULL,"Process is now system critical.\nPress OK to return it back to normal.",
				"Success!", MB_ICONINFORMATION | MB_OK);

	// Call it again - disable system critical status
	SetCriticalProcess(FALSE, NULL, FALSE);
	MessageBox(NULL,"Process is now un-critical.\nPress OK to exit.",
				"Success!", MB_ICONINFORMATION | MB_OK);

	return 0;
}
